@tool
extends CSGBox3D
class_name HollowBox
## A Hollow CSG box
##
## This creates a hollow csg box along the z-axis, with a given wall thickness. 

# Called when the node enters the scene tree for the first time.

## Wall thickness of the hollow box. 
@export var thickness := 0.1:
	set(value):
		thickness = value
		create()

@export_tool_button("Rebuild") var action := create

func _ready():
	create()
	
func create():
	var inner = null
	# find a procedurally created node
	for child in get_children():
		if child.owner == null:
			inner = child
			break
			
	if inner == null:
		inner = CSGBox3D.new()
		add_child(inner)
		inner.operation = CSGShape3D.OPERATION_SUBTRACTION
		
	if material:
		inner.material = material
	inner.size = size
	inner.size.x -= thickness * 2
	inner.size.y -= thickness * 2
	inner.size.z += 0.01 # Slightly taller to avoid "Z-fighting" or thin faces
