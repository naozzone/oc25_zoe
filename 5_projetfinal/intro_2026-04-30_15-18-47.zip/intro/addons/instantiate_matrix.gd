@tool
extends CSGCombiner3D
class_name Instantiatematrix 

@export var material : BaseMaterial3D
@export_tool_button("New Matrix", "CSGBox3D") var action1 = new_Matrix
@export var repeat = Vector3(2, 2, 2)
@export var step = Vector3(2, 2, 2)

@export_tool_button("Delete All", "Remove") var action4 = delete_all
  


## Instantiates a CSG box.
func new_Matrix():
	for x in repeat.x:
		for y in repeat.y:
			for z in repeat.z:
				var node = CSGBox3D.new()
				node.name = "Box"
				node.material = material
				add_child(node, true)
				node.position.x = x * step.x
				node.position.y = y * step.y
				node.position.z = z * step.z
				node.owner = get_tree().edited_scene_root
		


## Deletes all children.
func delete_all():
	for child in get_children():
		child.free()
